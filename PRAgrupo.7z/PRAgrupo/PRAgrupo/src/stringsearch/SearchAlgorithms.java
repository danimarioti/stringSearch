package stringsearch;

public interface SearchAlgorithms {

    public void callAlgorithm(String valor,String nomeArquivo);

}
